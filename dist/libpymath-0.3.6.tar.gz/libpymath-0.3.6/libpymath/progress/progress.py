import math
from collections.abc import Iterable
import time

class CharSet:
	def __init__(self, fill="█", blank=" ", half="▍"):
		self.fill = fill
		self.blank = blank
		self.half = half

	def eval(self, fill, length):
		fillChars = math.floor(length * fill)

		rem = (length * fill) % 1
		useHalf = rem > 0.25 and rem < 0.75

		res = self.fill * (fillChars + (1 if rem > 0.75 else 0)) + (self.half if useHalf else "")

		res += self.blank * (length - len(res))

		return res

class Progress:
	def __init__(self, iter=None, start=None, end=None, step=None, charset=None):
		self.iter = None
		self.start = None
		self.end = None
		self.step = None
		self.len = None
		self.charset = None

		self.count = 0
		self.maxIterLen = None

		# Start of __iter__
		self.startTime = 0

		# Iterations passed since previous update of bar
		self.iterationsPassed = 0

		# Time of the last update to the bar
		self.lastBarUpdate = 0

		if iter is None:
			# Use start, end and step
			if start is None:
				start = 0

			if end is None:
				raise ValueError("Either iter or end must be specified")

			if iter is None:
				iter = 1

			if not isinstance(start, (int, float)):
				raise TypeError("Start must be of type int or float")

			if not isinstance(end, (int, float)):
				raise TypeError("End must be of type int or float")

			if not isinstance(step, (int, float)):
				raise TypeError("Step must be of type int or float")

			if step == 0:
				raise ValueError("Step cannot be 0")

			if (end - start > 0 and step < 0) or (end - start < 0 and step > 0):
				raise Warning("Infinite loop created")

			self.start = start
			self.end = end
			self.step = step
			self.len = math.floor((end - start) / step)

		else:
			if not isinstance(iter, Iterable):
				raise TypeError("Iter must be an iterable object")

			self.iter = iter
			self.len = len(iter)

		if charset is None:
			self.charset = CharSet()
		elif isinstance(charset, CharSet):
			self.charset = charset

	def __iter__(self):
		iterable = self.iter
		start = time.time()
		its = 0
		count = 0
		iterationsPassed = 0
		previousIteration = 0
		maxLen = len(str(self.len))
		minutes = 0

		seconds = 0
		minutes = 0
		currentMinutes = 0
		currentSeconds = 0
		
		seconds = 0
		minutes = 0
		remainingMinutes = 0
		remainingSeconds = 0

		secondsPerIteration = False

		mod = 1
		timeMod = 1

		previousYield = time.time()

		for ob in iterable:
			yield ob

			# The current time
			current = time.time()

			# print(max(current - start, 0.0000001))
			delta = 1 / max(current - previousYield, 0.0000001)

			previousYield = current

			if delta < 1000:
				mod = 1
				timeMod = 1
			elif delta < 10000:
				mod = 10
				timeMod = 50
			elif delta < 100000:
				mod = 100
				timeMod = 1000
			elif delta < 1000000:
				mod = 1000
				timeMod = 10000000
			elif delta < 10000000:
				mod = 10000
				timeMod = 10000000000
			elif delta < 100000000:
				mod = 100000
				timeMod = 10000000000
			elif delta < 1000000000:
				mod = 1000000
				timeMod = 1000000000000
			else:
				mod = 10000000
				timeMod = 100000000000000

			count += 1
			iterationsPassed += 1

			if count % mod == 0:
				# The current time
				current = time.time()

				try:
					# Create the progress bar >>>  50%|##########__________| 50/100 [00:05|00:05  5 it/s]
					# Percentage
					prog = "{:>3}%".format(round((count / self.len) * 100))
					
					# Bar
					prog += "|{}|".format(self.charset.eval(count / self.len, 100))

					# X/Y
					prog += " {}/{}".format(str(count).rjust(maxLen), self.len)

					# Time
					if count % (timeMod) == 0:
						# Calculate the iterations per second
						dt = (current - previousIteration) if count != 1 else 1
						secondsPerIteration = dt > 1
						its = (iterationsPassed / dt) if not secondsPerIteration else (dt / iterationsPassed)

						dt = round(current - start)
						seconds = dt % 60
						minutes = (dt // 60) % 60
						currentMinutes = ("0" if len(str(minutes)) < 2 else "") + str(minutes)
						currentSeconds = ("0" if len(str(seconds)) < 2 else "") + str(seconds)

						dt = int((self.len - count) / its)
						seconds = dt % 60
						minutes = (dt // 60) % 60
						remainingMinutes = ("0" if len(str(minutes)) < 2 else "") + str(minutes)
						remainingSeconds = ("0" if len(str(seconds)) < 2 else "") + str(seconds)

					prog += " [{}:{}|<|{}:{}, {:.2f}{}]".format(currentMinutes, currentSeconds, remainingMinutes, remainingSeconds, its, "it/s" if secondsPerIteration else "s/it")
				except ZeroDivisionError:
					pass

				# Print the progress bar
				print(prog, end="\r")

				previousIteration = time.time()
				iterationsPassed = 0

		print()
		return


chars = CharSet(blank="░", half="@") # ("#", " ", "|")

"""
for i in range(10000):
	print(chars.eval(i / 10000, 100), end="\r")

	for j in range(10000):
		pass

print()
"""

loops = 1000 # 20

import libpymath as lpm

start = time.time()
for i in Progress(range(loops), charset=chars):
	x = lpm.matrix.Matrix(1000, 1000)
	y = lpm.matrix.Matrix(1000, 1)
	res = x @ y
end = time.time()
print("Completed in", end - start)
